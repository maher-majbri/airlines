﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for TicketsManager
/// </summary>
public class TicketsManager
{
    public TicketsManager()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataTable Select()
    {
        return Database.Execute("SELECT * FROM ReservationsView");
    }

   




}