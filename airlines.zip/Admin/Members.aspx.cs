﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Members : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
         MemberManager.Insert(txtName.Text,txtEmail.Text,txtPhone.Text,txtPassword.Text,Convert.ToInt16 (ddlCity.SelectedValue));
        ddlCity.DataBind();
        GridView1.DataBind();
        ClearForm();
    }

    private void ClearForm()
    {
        txtName.Text = "";
        txtEmail.Text ="";
        txtPhone.Text="";
        txtPassword.Text = "";
    }
    
}