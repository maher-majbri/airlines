﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Flights : System.Web.UI.Page
{
 
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        FlightsManager.Insert(Convert.ToInt16(ddlCompany.SelectedValue), Convert.ToInt16(ddlFrom.SelectedValue), Convert.ToInt16(ddlTo.SelectedValue), Convert.ToDouble(txtPrice.Text), Convert.ToString(ddlClass.SelectedItem));
        GridView1.DataBind();
        ClearForm();
    }

    private void ClearForm()
    {
        txtPrice.Text = "";

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
}